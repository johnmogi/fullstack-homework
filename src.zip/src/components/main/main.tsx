import React, { Component } from "react";

import "./main.css";

class Main extends React.Component {
  render() {
    return <div className="main">HERO</div>;
  }
}

export default Main;
