import React, { Component } from "react";

import "./header.css";

class Header extends React.Component {
  render() {
    return <div className="header">NAVBAR</div>;
  }
}

export default Header;
