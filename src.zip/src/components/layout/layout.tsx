import React, { Component } from "react";

import "./layout.css";
import Footer from "../footer/footer";
import Header from "../header/header";
import Sidebar from "../sidebar/sidebar";
import Main from "../main/main";
// import Footer from '../footer/footer';
class Layout extends Component {
  render() {
    return (
      <div className="layout">
        <header>
          <Header />
        </header>
        <main>
          <Sidebar />
          <Main />
        </main>
        <footer>
          <Footer />
        </footer>
      </div>
    );
  }
}

export default Layout;
