import React, { Component } from "react";

import "./layout.css";
import Footer from "../footer/footer";
import Header from "../header/header";
import Sidebar from "../sidebar/sidebar";
import Main from "../main/main";

import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";
 import { Products } from "../products/products";
import { About } from "../about/about";
import Insert from "../insert/insert";
import Update from "../update/update";
import Details from "../details/details";


import Grid from "@material-ui/core/Grid";
import Container from "@material-ui/core/Container";

// import Footer from '../footer/footer';
class Layout extends Component {
  render() {
    return (
        <BrowserRouter>
      <Container className="layout">
        <header>
          <Header />
        </header>
        <main>
          <Grid container spacing={1}>
            <Grid item xs={3}>
            <Sidebar />
            </Grid>
            <Grid item xs={9}>
            <Switch>
                            <Route path="/home" component={Main} exact />
                            <Route path="/products" component={Products} exact />
                            <Route path="/products/new" component={Insert} exact />
                            <Route path="/products/:id" component={Update} exact />
                            <Route path="/details/:id" component={Details} exact />
                            <Route path="/about" component={About} exact />
                            <Redirect from="/" to="/home" exact />
                        </Switch>
            </Grid>
          </Grid>
        </main>
        <footer>
          <Footer />
        </footer>
      </Container>
      </BrowserRouter>

    );
  }
}

export default Layout;
