import React, { ChangeEvent } from "react";
import "./details.css";
import { ProductModel } from "../../models/product-model";
import { NavLink } from "react-router-dom";

export interface DetailsState {
    product: ProductModel
}

class Details extends React.Component<any, DetailsState> {

    constructor(props: any) {
        super(props);
        this.state = {
            product: new ProductModel()
        };
    }

    public componentDidMount() {
        const id = +this.props.match.params.id;
        fetch("http://localhost:3000/api/products/" + id)
            .then(response => response.json())
            .then(product => this.setState({ product }))
            .catch(err => alert(err.message));
    }

    public render() {
        return (
            <div className="details">

                <h2>Product Details</h2>

                <h3>Name: {this.state.product.name}</h3>
                <h3>Price: {this.state.product.price}</h3>
                <h3>Stock: {this.state.product.stock}</h3>

                <NavLink to="/products" exact>Back to List</NavLink>

            </div>
        );
    }
}

export default Details;