import React, { ChangeEvent } from "react";
import "./update.css";
import { ProductModel } from "../../models/product-model";
import { NavLink } from "react-router-dom";

export interface UpdateState {
    product: ProductModel
}

class Update extends React.Component<any, UpdateState> {

    constructor(props: any) {
        super(props);
        this.state = {
            product: new ProductModel()
        };
    }

    public componentDidMount() {
        const id = +this.props.match.params.id;
        fetch("http://localhost:3000/api/products/" + id)
            .then(response => response.json())
            .then(product => this.setState({product}))
            .catch(err => alert(err.message));
    }

    private setName = (args: ChangeEvent<HTMLInputElement>) => { // args = input event arguments
        const name = args.target.value;
        const product = { ...this.state.product }; // Duplicate
        product.name = name;
        this.setState({ product });
    };

    private setPrice = (args: ChangeEvent<HTMLInputElement>) => {
        const price = +args.target.value;
        const product = { ...this.state.product };
        product.price = price;
        this.setState({ product });
    };

    private setStock = (args: ChangeEvent<HTMLInputElement>) => {
        const stock = +args.target.value;
        const product = { ...this.state.product };
        product.stock = stock;
        this.setState({ product });
    };

    private updateProduct = () => {

        const options = {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(this.state.product)
        };

        fetch("http://localhost:3000/api/products/" + this.state.product.id, options)
            .then(response => response.json())
            .then(product => {
                alert("Product has been updated! ID: " + product.id);
                this.props.history.push("/products");
            })
            .catch(err => alert(err.message));
    };

    public render() {
        return (
            <div className="update">

                <h2>Update Product</h2>

                <form>

                    <input type="text" placeholder="Name..." onChange={this.setName} value={this.state.product.name || ""} />

                    <input type="number" placeholder="Price..." onChange={this.setPrice} value={this.state.product.price || ""} />

                    <input type="number" placeholder="Stock..." onChange={this.setStock} value={this.state.product.stock || ""} />

                    <button type="button" onClick={this.updateProduct}>Update</button>

                </form>

                <NavLink to="/products" exact>Back to List</NavLink>

            </div>
        );
    }
}

export default Update;