import React, { Component } from "react";

import "./main.css";

class Main extends React.Component {
  render() {
    return (
      <div className="main">
        <img src="/assets/images/logo.jpg" alt="Northwind" />
        Wellcome to Northwind
      </div>
    );
  }
}

export default Main;
