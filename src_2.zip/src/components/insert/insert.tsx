import React, { ChangeEvent } from "react";
import "./insert.css";
import TextField from "@material-ui/core/TextField";

import { ProductModel } from "../../models/product-model";
import { NavLink } from "react-router-dom";

export interface InsertState {
  product: ProductModel;
}

class Insert extends React.Component<any, InsertState> {
  constructor(props: any) {
    super(props);
    this.state = {
      product: new ProductModel()
    };
  }

  private setName = (args: ChangeEvent<HTMLInputElement>) => {
    // args = input event arguments
    const name = args.target.value;
    const product = { ...this.state.product }; // Duplicate
    product.name = name;
    this.setState({ product });
  };

  private setPrice = (args: ChangeEvent<HTMLInputElement>) => {
    const price = +args.target.value;
    const product = { ...this.state.product };
    product.price = price;
    this.setState({ product });
  };

  private setStock = (args: ChangeEvent<HTMLInputElement>) => {
    const stock = +args.target.value;
    const product = { ...this.state.product };
    product.stock = stock;
    this.setState({ product });
  };

  private addProduct = () => {
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify(this.state.product)
    };

    fetch("http://localhost:5000/api/products", options)
      .then(response => response.json())
      .then(product => {
        alert("Product has been added! ID: " + product.id);
        this.props.history.push("/products");
      })
      .catch(err => alert(err.message));
  };

  public render() {
    return (
      <div className="insert">
        <h2>Insert Product</h2>

        <form>
          <input
            type="text"
            placeholder="Name..."
            onChange={this.setName}
            value={this.state.product.name || ""}
          />

          <input
            type="number"
            placeholder="Price..."
            onChange={this.setPrice}
            value={this.state.product.price || ""}
          />

          <input
            type="number"
            placeholder="Stock..."
            onChange={this.setStock}
            value={this.state.product.stock || ""}
          />

          <button type="button" onClick={this.addProduct}>
            Add
          </button>
        </form>

        <NavLink to="/products" exact>
          Back to List
        </NavLink>
      </div>
    );
  }
}

export default Insert;
