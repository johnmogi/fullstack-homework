import React, { Component } from "react";
import "./about.css";

export class About extends Component {
    public render(): JSX.Element {
        return (
            <div className="about">
                <h2>About</h2>
            </div>
        );
    }
}
