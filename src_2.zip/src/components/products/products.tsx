import React, { Component } from "react";
import "./products.css";
import { ProductModel } from "../../models/product-model";
import { NavLink } from "react-router-dom";

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';



interface ProductsState {
    products: ProductModel[];
}

export class Products extends Component<any, ProductsState> {

    public constructor(props: any) {
        super(props);
        this.state = { // Init the state.
            products: []
        };
    }

    public componentDidMount(): void {
        fetch("http://localhost:5000/api/products")
            .then(response => response.json())
            .then(products => this.setState({ products }))
            .catch(err => alert(err.message));
    }

    private deleteProduct = (id: number) => {

        const answer = window.confirm("Are you sure?");
        if (!answer) {
            return;
        }

        const options = {
            method: "DELETE"
        };

        fetch("http://localhost:5000/api/products/" + id, options)
            .then(() => {
                alert("Product has been deleted!");
                this.componentDidMount();
            })
            .catch(err => alert(err.message));
    };

    public render(): JSX.Element {
       

        return (
            <div className="products">
                <h2>{this.state.products.length} Products</h2>
                <TableContainer>
                <Table aria-label="simple table">
                <TableHead>
                <TableRow>    
          <TableCell>Name</TableCell>
            <TableCell>Price</TableCell>
            <TableCell>Stock</TableCell>
            <TableCell>Edit</TableCell>
            <TableCell>Delete</TableCell>
        </TableRow>
        </TableHead>
        <TableBody>
              {this.state.products.map(p =>
            <TableRow key={p.id}>
      
              <TableCell align="right"> <NavLink to={"/details/" + p.id} exact>{p.name}</NavLink></TableCell>
              <TableCell align="right">{p.price}</TableCell>
              <TableCell align="right">{p.stock}</TableCell>
              <TableCell align="right"><NavLink to={"/products/" + p.id} exact>Edit</NavLink></TableCell>
              <TableCell align="right"><a href="javascript:void" onClick={() => this.deleteProduct(p.id)}>Delete</a></TableCell>
            </TableRow>
              )};
          </TableBody>
      </Table>
    </TableContainer>
            </div>
        );
    }
}