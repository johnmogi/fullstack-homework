import React, { Component } from "react";

import "./footer.css";

class Footer extends React.Component {
  render() {
    return (
      <div className="footer">
        all rights reserved &copy;
        <a href="http://johnmogi.com">John Mogi</a>
      </div>
    );
  }
}

export default Footer;
